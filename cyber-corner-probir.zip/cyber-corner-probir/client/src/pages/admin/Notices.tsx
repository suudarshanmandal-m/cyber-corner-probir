import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { useAuth } from "@/hooks/use-auth";
import { useNotices } from "@/hooks/use-service-requests";

export default function AdminNotices() {
  const [, setLocation] = useLocation();
  const { admin, isLoading } = useAuth();
  const { notices, createNotice, deleteNotice } = useNotices();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!isLoading && !admin) setLocation("/admin/login");
  }, [admin, isLoading]);

  if (isLoading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!admin) return null;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;
    setSubmitting(true);
    setError("");
    try {
      await createNotice({ title, content });
      setTitle("");
      setContent("");
    } catch (err: any) {
      setError(err.message || "Failed to create notice");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm("Delete this notice?")) await deleteNotice(id);
  };

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AdminSidebar />
        <main className="flex-1 p-6">
          <h1 className="text-2xl font-bold mb-6">Notices</h1>

          <Card className="mb-6">
            <CardHeader><CardTitle className="text-base">Add New Notice</CardTitle></CardHeader>
            <CardContent>
              <form onSubmit={handleCreate} className="space-y-3">
                <div>
                  <Label>Title</Label>
                  <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Notice title" className="mt-1" />
                </div>
                <div>
                  <Label>Content</Label>
                  <Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Notice content..." rows={3} className="mt-1" />
                </div>
                {error && <p className="text-destructive text-sm">{error}</p>}
                <Button type="submit" disabled={submitting} className="gap-2">
                  <Plus className="h-4 w-4" />
                  {submitting ? "Adding..." : "Add Notice"}
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="space-y-3">
            {notices.length === 0 && (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">No notices yet.</CardContent>
              </Card>
            )}
            {notices.map((notice: any, i: number) => (
              <motion.div key={notice.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <Card>
                  <CardContent className="p-4 flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold">{notice.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{notice.content}</p>
                      <p className="text-xs text-muted-foreground mt-2">{new Date(notice.createdAt).toLocaleString("en-IN")}</p>
                    </div>
                    <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive flex-shrink-0"
                      onClick={() => handleDelete(notice.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
