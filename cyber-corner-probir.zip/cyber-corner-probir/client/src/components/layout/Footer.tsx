import { motion } from "framer-motion";
import { useI18n } from "@/lib/i18n";
import { Phone, MapPin, Monitor } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";

export default function Footer() {
  const { t } = useI18n();

  return (
    <motion.footer
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
      className="bg-foreground text-background"
    >
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Monitor className="h-6 w-6 text-primary" />
              <h3 className="text-xl font-bold">CYBER CORNER</h3>
            </div>
            <p className="text-background/70 text-sm">{t.owner}</p>
            <p className="text-background/70 text-sm mt-2">{t.heroSubtitle}</p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <div className="space-y-2 text-background/70 text-sm">
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>{t.footerAddress}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 flex-shrink-0" />
                <span>9832450395 | 6297320156</span>
              </div>
              <a
                href="https://wa.me/916297320156"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-green-400 hover:text-green-300 transition-colors"
              >
                <motion.div whileHover={{ scale: 1.1 }}>
                  <FaWhatsapp className="h-4 w-4" />
                </motion.div>
                <span>{t.whatsapp}</span>
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-1 text-background/70 text-sm">
              {Object.values(t.services).map((service) => (
                <li key={service} className="hover:text-background transition-colors">{service}</li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-background/20 mt-8 pt-6 text-center text-background/50 text-sm">
          <p>© {new Date().getFullYear()} CYBER CORNER. {t.footerRights}</p>
        </div>
      </div>
    </motion.footer>
  );
}
