import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";

export default function Navbar() {
  const { t, lang, setLang } = useI18n();
  const [location] = useLocation();

  const navLinks = [
    { href: "/", label: t.home },
    { href: "/request", label: t.request },
    { href: "/track", label: t.track },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Monitor className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg font-display">CYBER CORNER</span>
        </Link>

        <div className="flex items-center gap-1">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href}>
              <span className={`relative px-3 py-1.5 text-sm font-medium rounded-md transition-colors cursor-pointer
                ${location === link.href ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                {location === link.href && (
                  <motion.span
                    layoutId="navIndicator"
                    className="absolute inset-0 bg-primary/10 rounded-md"
                    transition={{ type: "spring", duration: 0.4 }}
                  />
                )}
                <span className="relative">{link.label}</span>
              </span>
            </Link>
          ))}

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLang(lang === "en" ? "bn" : "en")}
            className="ml-2 text-xs font-semibold"
          >
            {lang === "en" ? "বাংলা" : "English"}
          </Button>
        </div>
      </div>
    </nav>
  );
}
