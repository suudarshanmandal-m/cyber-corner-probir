export async function getSystemStats(db: any) {
  const users = await db.query.users.findMany();
  return {
    totalUsers: users.length,
    generatedAt: new Date()
  };
}
