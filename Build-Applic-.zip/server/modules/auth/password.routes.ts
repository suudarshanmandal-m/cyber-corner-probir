import { Router } from "express";
import crypto from "crypto";
import bcrypt from "bcryptjs";

const router = Router();

router.post("/request-reset", async (req: any, res) => {
  const { email } = req.body;
  const token = crypto.randomBytes(32).toString("hex");
  const hashed = await bcrypt.hash(token, 10);

  await req.db.update("users")
    .set({ resetToken: hashed, resetTokenExpiry: new Date(Date.now() + 3600000) })
    .where({ email });

  res.json({ message: "Reset token generated", token }); // Replace with email send in production
});

router.post("/reset-password", async (req: any, res) => {
  const { token, password } = req.body;

  const users = await req.db.query.users.findMany();
  const user = users.find(u => u.resetToken);

  if (!user) return res.status(400).json({ message: "Invalid token" });

  const valid = await bcrypt.compare(token, user.resetToken);
  if (!valid) return res.status(400).json({ message: "Invalid token" });

  const hashedPassword = await bcrypt.hash(password, 10);

  await req.db.update("users")
    .set({ password: hashedPassword, resetToken: null, resetTokenExpiry: null })
    .where({ id: user.id });

  res.json({ message: "Password updated" });
});

export default router;
