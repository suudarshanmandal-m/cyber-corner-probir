import { Router } from "express";
import { requireAuth, requireAdmin } from "../../middleware/role";
import { getSystemStats } from "../../services/analytics.service";

const router = Router();

router.get("/stats", requireAuth, requireAdmin, async (req, res) => {
  const stats = await getSystemStats((req as any).db);
  res.json(stats);
});

export default router;
