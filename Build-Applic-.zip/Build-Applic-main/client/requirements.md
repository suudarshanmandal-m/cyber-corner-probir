## Packages
framer-motion | Page transitions and animations

## Notes
Service request form requires multipart/form-data for document upload.
Authentication checks /api/auth/me to protect /admin routes.
